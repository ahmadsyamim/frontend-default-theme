@include('default.partials.meta')
@include('default.partials.header')

<main class="main-content">
    @yield('content')
</main>

@include('default.partials.footer')
